
var config = {
    mode: "fixed_servers",
    rules: {
        singleProxy: {
            scheme: "http",
            host: "in.proxymesh.com",
            port: parseInt(31280)
        },
        bypassList: ["localhost","127.0.0.1"]
    }
};

chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

function callbackFn(details) {
    return {
        authCredentials: {
            username: "anon",
            password: "Shiraz@proxymesh123"
        }
    };
}

chrome.webRequest.onAuthRequired.addListener(
    callbackFn,
    {urls: ["https://x.com/*"]},
    ["blocking"]
);
